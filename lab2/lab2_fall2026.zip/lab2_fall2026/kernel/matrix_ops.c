#include "matrix_ops.h"

#ifndef BLOCK_SIZE_I
#define BLOCK_SIZE_I 169
#endif

#ifndef BLOCK_SIZE_J
#define BLOCK_SIZE_J 32
#endif

#ifndef BLOCK_SIZE_K
#define BLOCK_SIZE_K 9
#endif


float **matmul(float **A, float **B, int A_rows, int A_cols, int B_rows, int B_cols)
{
    // TODO: Implement matrix multiplication
}

// Matmul with blocking optimization
float **matmul_blocking(float **A, float **B, int A_rows, int A_cols, int B_rows, int B_cols)
{
    // TODO: Implement matrix multiplication with blocking (loop tiling)
}

// Matmul with quantization
float **matmul_quant(unsigned int **A, int **B, int A_rows, int A_cols, int B_rows, int B_cols)
{
    // TODO: Implement matrix multiplication with quantized matrix A and unquantized matrix B.
    //       The input matrix A stores data in a 4-byte granularity, i.e., A[i][k] is a 4-byte unsigned integer.
    //       However, each element of A takes 8-bit (1-byte) storage space, meadning that A[i][k] contains multiple elements.
    //       The input matrix B is unquantized, and each element of B is a 4-byte integer.
    //       The returned output matrix should be "float". You can achieve this by performing dot product in integer, and use type casting to convert the output to float.

    if ( ((QUANT_PRECISION % 2) != 0) || (QUANT_PRECISION > 16) )
    {
        printf("Incompatible precision assigned to the matrix.\n");
        return NULL;
    }

    if ( (A_cols * (sizeof(unsigned int)*8) / QUANT_PRECISION) != B_rows )
    {
        printf("Matrix dimensions incompatible for multiplication.\n");
        return NULL;
    }

    // HINT: 1. Since every quantized element in matrix A is 8-bit, how many elements can be packed in a 4-byte unsigned integer?
    // HINT: 2. For a 4-byte unsigned integer in matrix A, how to use Boolean masking to extract the actual 8-bit elements?
    // HINT: 3. Make sure to calculate the correct 'k' index of A and B when performing dot-product.

    return NULL;
}